import code
import random, string, requests
import Slay

def nitro_check():
    code_nitro = ''.join([random.choice(string.ascii_uppercase + string.digits) for _ in range(16)])
    url_nitro = f'https://discord.com/gifts/{code_nitro}'
    print(f"discord.gift/{code} Is valid fr")
    Slay.main()
